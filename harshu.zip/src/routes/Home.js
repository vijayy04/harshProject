import { useNavigate } from "react-router-dom";
import './home.css'
import scooter from '../assets/images/scooter.svg'
import scooter1 from '../assets/images/scooter2.webp'
import motorcycle from '../assets/images/motorcycle.svg'
import logo from '../assets/images/1.png'
import cycle from '../assets/images/cycle.svg'
import { useState } from "react";
import HorizontalScroll from 'react-horizontal-scrolling'
import { scooterData } from '../assets/JSON-details/scooterDetails';
import Select from "react-select"
import { MdLocationOn } from 'react-icons/md';
import { AiFillLike } from 'react-icons/ai';
import movie1 from "../assets/images/movie1.png"
import letter from "../assets/images/letter.svg"
import ticket from "../assets/images/ticket.svg"
import customer from "../assets/images/customer.svg"
import MovieData from "../recoil/MovieData";
import { useRecoilState } from "recoil";
import Header from "../components.js/Header";

function Home() {
  const [movie, setMovie] = useRecoilState(MovieData);
  const navigate = useNavigate();

  return (
    <div className=" w-full float-left fonts font-light font-sans">

      {/* header part */}
      <Header />

      {/* movies list */}
      <div className="w-full pt-[3%] pl-[10%] pr-[10%] float-left">

        {movie.map((ele, index) => {
          return (
            <div
              onClick={() => {
                navigate(`/movie/${ele.name}`)
              }}
              key={index} className="w-[20%] cursor-pointer hover:scale-[103%] transition float-left mr-[5%] mb-[2%]">
              {/* movie banner */}
              <div className="w-[100%] relative float-left">
                <img className="rounded-[7px] w-[100%]" src={ele.movieBanner} alt="load" />
                <div className="absolute flex justify-start w-[100%] borderTop py-[2%] px-[6%] bottom-0 z-10 float-left">
                  <AiFillLike className="text-[green]" size={25} />
                  <span className="text-[white] font-light ml-[3%]">9.6k Likes</span>
                </div>
              </div>

              <div className="w-[100%] relative float-left">
                <div className="w-[100%] text-[1.2vw] mt-[1%] ml-[1%] float-left font-sans font-medium text-[black]">{ele.name}</div>
                <div className="w-[100%] ml-[1%] text-[#666666] font-sans float-left">{ele.type}</div>
              </div>
            </div>
          )
        })}

      </div>

      {/* detail part  */}
      <div className="w-full px-[10%] float-left bg-[#353535] py-[1%] mt-[4%]">
        <div className="w-[33%] float-left flex justify-center">
          <div className="w-[100%] float-left">
            <div className="w-[100%] flex justify-center float-left">
              <img className="w-[10%]" src={customer} alt="load" />
            </div>
            <div className="w-[100%] text-center float-left text-[#181818]">24/7 Customer Care</div>
          </div>
        </div>
        <div className="w-[33%] float-left flex justify-center">
          <div className="w-[100%] float-left">
            <div className="w-[100%] flex justify-center float-left">
              <img className="w-[10%]" src={ticket} alt="load" />
            </div>
            <div className="w-[100%] text-center float-left text-[#181818]">Resend Booking Confirmation</div>
          </div>
        </div>
        <div className="w-[33%] float-left flex justify-center">
          <div className="w-[100%] float-left">
            <div className="w-[100%] flex justify-center float-left">
              <img className="w-[10%]" src={letter} alt="load" />
            </div>
            <div className="w-[100%] text-center float-left text-[#181818]">Subscribe to the newsletter</div>
          </div>
        </div>
      </div>

      <div className="w-full fonts float-left px-[10%] py-[1%] text-center text-[.8vw] text-[white] bg-[#020202] font-thin">
        Copyright 2023 © Bigtree Entertainment Pvt. Ltd. All Rights Reserved.
        The content and images used on this site are copyright protected and copyrights vests with the respective owners.
        The usage of the content and images on this website is intended to promote the
        works and no endorsement of the artist shall be implied. Unauthorized use is prohibited and punishable by law.
      </div>

    </div>
  );
}

export default Home;
