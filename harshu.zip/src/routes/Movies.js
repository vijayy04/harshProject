import { Link, useNavigate, useParams } from "react-router-dom";
import './home.css'
import scooter from '../assets/images/scooter.svg'
import scooter1 from '../assets/images/scooter2.webp'
import motorcycle from '../assets/images/motorcycle.svg'
import logo from '../assets/images/1.png'
import cycle from '../assets/images/cycle.svg'
import { useState } from "react";
import HorizontalScroll from 'react-horizontal-scrolling'
import { scooterData } from '../assets/JSON-details/scooterDetails';
import Select from "react-select"
import { MdLocationOn } from 'react-icons/md';
import { AiFillLike } from 'react-icons/ai';
import movie1 from "../assets/images/movie1.png"
import letter from "../assets/images/letter.svg"
import ticket from "../assets/images/ticket.svg"
import customer from "../assets/images/customer.svg"
import MovieData from "../recoil/MovieData";
import { useRecoilState } from "recoil";
import Header from "../components.js/Header";

function Movies() {
  const [movie, setMovie] = useRecoilState(MovieData);
  const { movieName } = useParams();
  const navigate = useNavigate();

  const data = movie.find(ele => ele.name === movieName);

  console.log(data)

  return (
    <div className=" w-full float-left fonts font-light font-sans">

      {/* header part */}
      <Header />

      {/* movies list */}
      <div className="w-full py-[2%] px-[10%] bg-[#1a1a1a] float-left">
        <div className="w-[20%] float-left">
          <img className="rounded-[12px] w-[100%]" src={data.movieBanner} alt="load" />
        </div>

        {/* movie detail */}
        <div className="w-[80%] px-[2%] float-left">
          <div className="w-[100%] float-left">
            <div className="w-[100%] float-left text-[white] text-[2vw] pt-[2%]">{data.name}</div>

            <div className="w-[50%] px-[2%] mt-[1%] py-[.5%] rounded-[10px] float-left text-[white] text-[2.5vw] bg-[#333]">
              <div className="w-[70%] float-left">
                <divc className="w-[100%] mt-[2.2%] text-[1.2vw] float-left">Add your rating & review</divc>
                <divc className="w-[100%] text-[1.1vw] text-[#cccccc] fonts float-left">Your ratings matter</divc>
              </div>
              <div className="w-[30%] text-center py-[2%] mt-[2.2%] bg-[white] text-[1.1vw] text-[#333] rounded-[10px] float-left">
                Rate Now
              </div>
            </div>

            <div className="w-[100%] flex justify-start float-left mt-[3%]">
              <button className="bg-[#e5e5e5] text-[#1a1a1a] text-[1.1vw] mr-[1%] px-[.6%] rounded-[3px] ">{data.movieD}</button>
              {data.language.map((ele, index) => {
                return (
                  <button className="bg-[#e5e5e5] text-[#1a1a1a] text-[1.1vw] mr-[1%] px-[.6%] rounded-[3px] ">{ele}</button>
                )
              })}
            </div>

            <div className="w-[100%] flex justify-start text-[1.2vw] text-[white] float-left mt-[3%]">
              {data.movieTime} . {data.type} . {data.releaseDate}
            </div>

            <div className="w-[20%] text-center bg-[#f84464] py-[1.1%] rounded-[12px] text-[1.2vw] text-[white] float-left mt-[3%]">
              Book Tickets
            </div>

          </div>
        </div>
      </div>

      {/* detail part  */}
      <div className="w-full px-[10%] float-left bg-[#353535] py-[1%] mt-[4%]">
        <div className="w-[33%] float-left flex justify-center">
          <div className="w-[100%] float-left">
            <div className="w-[100%] flex justify-center float-left">
              <img className="w-[10%]" src={customer} alt="load" />
            </div>
            <div className="w-[100%] text-center float-left text-[#181818]">24/7 Customer Care</div>
          </div>
        </div>
        <div className="w-[33%] float-left flex justify-center">
          <div className="w-[100%] float-left">
            <div className="w-[100%] flex justify-center float-left">
              <img className="w-[10%]" src={ticket} alt="load" />
            </div>
            <div className="w-[100%] text-center float-left text-[#181818]">Resend Booking Confirmation</div>
          </div>
        </div>
        <div className="w-[33%] float-left flex justify-center">
          <div className="w-[100%] float-left">
            <div className="w-[100%] flex justify-center float-left">
              <img className="w-[10%]" src={letter} alt="load" />
            </div>
            <div className="w-[100%] text-center float-left text-[#181818]">Subscribe to the newsletter</div>
          </div>
        </div>
      </div>

      <div className="w-full fonts float-left px-[10%] py-[1%] text-center text-[.8vw] text-[white] bg-[#020202] font-thin">
        Copyright 2023 © Bigtree Entertainment Pvt. Ltd. All Rights Reserved.
        The content and images used on this site are copyright protected and copyrights vests with the respective owners.
        The usage of the content and images on this website is intended to promote the
        works and no endorsement of the artist shall be implied. Unauthorized use is prohibited and punishable by law.
      </div>

    </div>
  );
}

export default Movies;
