export const scooterData = [
  {
    id: 1,
    img: 'http://localhost:3000/static/media/scooter2.a901c2afdb214ecdadd8.webp',
    model: 'Activa 6G 2022',
    address: 'HSR layout, Urban Banglore',
    price: 1500,
    rating: 4.7,
    trips: 54,
    total: 6000
  },
  {
    id: 1,
    img: 'http://localhost:3000/static/media/scooter2.a901c2afdb214ecdadd8.webp',
    model: 'Activa 6G 2022',
    address: 'HSR layout, Urban Banglore',
    price: 1500,
    rating: 4.7,
    trips: 54,
    total: 6000
  },
  {
    id: 1,
    img: 'http://localhost:3000/static/media/scooter2.a901c2afdb214ecdadd8.webp',
    model: 'Activa 6G 2022',
    address: 'HSR layout, Urban Banglore',
    price: 1500,
    rating: 4.7,
    trips: 54,
    total: 6000
  },
  {
    id: 1,
    img: 'http://localhost:3000/static/media/scooter2.a901c2afdb214ecdadd8.webp',
    model: 'Activa 6G 2022',
    address: 'HSR layout, Urban Banglore',
    price: 1500,
    rating: 4.7,
    trips: 54,
    total: 6000
  }
  ,{
    id: 1,
    img: 'http://localhost:3000/static/media/scooter2.a901c2afdb214ecdadd8.webp',
    model: 'Activa 6G 2022',
    address: 'HSR layout, Urban Banglore',
    price: 1500,
    rating: 4.7,
    trips: 54,
    total: 6000
  }
]
