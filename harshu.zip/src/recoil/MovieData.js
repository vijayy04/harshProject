import { atom } from "recoil";
import movie1 from "../assets/images/movie1.png"
import movie2 from "../assets/images/movie2.png"
import movie3 from "../assets/images/movie3.png"
import movie4 from "../assets/images/movie4.png"
import movie5 from "../assets/images/movie5.png"
import movie6 from "../assets/images/movie6.png"
import movie7 from "../assets/images/movie7.png"
import movie8 from "../assets/images/movie8.png"

const dummyData = [
  {
    movieBanner: movie1,
    movieTime: "1h 52m",
    releaseDate: "13 Jan 2023",
    movieD: "2d",
    language: ["Hindi"],
    name: "kuttey",
    type: "Thriller"
  },
  {
    movieBanner: movie2,
    movieTime: "2h 50m",
    releaseDate: "13 Jan 2023",
    movieD: "3d",
    language: ["Hindi", "English"],
    name: "Avatar",
    type: "Action/Fantasy"
  },
  {
    movieBanner: movie3,
    movieTime: "2h 40m",
    releaseDate: "13 Jan 2023",
    movieD: "2d",
    language: ["Hindi", "Telugu"],
    name: "Varisu(Hindi)",
    type: "Action/Drama"
  },
  {
    movieBanner: movie4,
    movieTime: "3h 12m",
    releaseDate: "16 Dec 2022",
    movieD: "2d",
    language: ["Hindi", "Telugu"],
    name: "Waltair Veerayya",
    type: "Action/Drama"
  },
  {
    movieBanner: movie5,
    movieTime: "2h 50m",
    releaseDate: "12 Jan 2023",
    movieD: "2d",
    language: ["Hindi", "Tamil"],
    name: "Veera Simha Ready",
    type: "Action/Drama"
  },
  {
    movieBanner: movie6,
    movieTime: "2h 20m",
    releaseDate: "18 Nov 2022",
    movieD: "2d",
    language: ["Hindi"],
    name: "Drishyam2",
    type: "Drama/Mystery/Thriller"
  },
  {
    movieBanner: movie7,
    movieTime: "2h 36m",
    releaseDate: "25 Nov 2022",
    movieD: "2d",
    language: ["Hindi"],
    name: "Bhediya",
    type: "Comedy/Thriller"
  },
  {
    movieBanner: movie8,
    movieTime: "2h 22m",
    releaseDate: "23 Dec 2022",
    movieD: "2d",
    language: ["Hindi"],
    name: "Cirkus",
    type: "Comedy/Drama"
  },
]

const MovieData = atom({
  key: "movieInfo",
  default: dummyData,
});

export default MovieData;