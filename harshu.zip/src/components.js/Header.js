import { Link } from "react-router-dom";
import '../routes/home.css'
import scooter from '../assets/images/scooter.svg'
import scooter1 from '../assets/images/scooter2.webp'
import motorcycle from '../assets/images/motorcycle.svg'
import logo from '../assets/images/1.png'
import cycle from '../assets/images/cycle.svg'
import { useState } from "react";
import HorizontalScroll from 'react-horizontal-scrolling'
import { scooterData } from '../assets/JSON-details/scooterDetails';
import Select from "react-select"
import { MdLocationOn } from 'react-icons/md';
import { AiFillLike } from 'react-icons/ai';
import movie1 from "../assets/images/movie1.png"
import letter from "../assets/images/letter.svg"
import ticket from "../assets/images/ticket.svg"
import customer from "../assets/images/customer.svg"
import MovieData from "../recoil/MovieData";
import { useRecoilState } from "recoil";

function Header() {
  const [movie, setMovie] = useRecoilState(MovieData);

  const data = movie.map((ele, index) => {
    let arr = {
      label: ele.name,
      value: index
    };
    return arr
  })

  return (
    <div className="w-full m-auto bg-[#020202] float-left">
      <div className="w-[80%] ml-[10%] float-left">

        {/* img part */}
        <div className="w-[10%] float-left">
          <img src={logo} alt="load" />
        </div>

        <div className="pt-[3.5%] w-[28%] font-light float-left">
          <Select
            styles={{
              control: (baseStyles, state) => ({
                ...baseStyles,
                borderColor: state.isFocused ? 'grey' : 'black',
                padding: ".4%",
                fontSize: "1.1vw",
                fontWeight: "lighter"
              }),
            }}
            options={data}
            placeholder="Search for Movies"
          />
        </div>

        <div className="pt-[3.8%] w-[20%] flex justify-end font-light float-right">
          <MdLocationOn className=" text-[white]" size={30} />
          <span className="text-[white] text-[1vw] mt-[1%] ml-[2%]">Jodhpur</span>
        </div>

      </div>
    </div>
  )
}

export default Header