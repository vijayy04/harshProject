import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import './App.css';
import Home from "./routes/Home"
import Movies from "./routes/Movies";

function App() {
  return (
    <BrowserRouter>
      <div>

        <div className="App">
          <Routes>
            <Route path="/" element={<Navigate replace to="/movie" />} />

            <Route
              path="/movie"
              element={<Home></Home>}
            />
            <Route
              path="/movie"
              element={<Home></Home>}
            />
            <Route
              path="/movie/:movieName"
              element={<Movies></Movies>}
            />
          </Routes>

        </div>
      </div>
    </BrowserRouter>
  );
}

export default App;